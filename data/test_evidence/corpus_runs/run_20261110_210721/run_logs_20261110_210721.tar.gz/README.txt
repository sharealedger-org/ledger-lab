Baseline run 20261110_210721: raw logs. The launcher stdout for this run (run2_corpus.log) was not kept.
